This version is distributed under GNU GPL v2 license. To get this product 
under other license for your commercial product development please contact 
us at sales@zaval.org.

This release includes demo optimized for Sharp Zaurus and Compaq iPAQ - try
corresponding 'runPJDemo' script.

Note for developers: read changelog and doc/changes.doc before 
migrating to this version.

This release contains all docs in MS Word format (see 'docs' directory).
Other formats are also available and can be downloaded from our site:
http://www.zaval.org/products/lwvcl/tutorial/
