/*
 * FXGrid.java
 *
 * Created on September 26, 2002, 10:03 AM
 */

package lwvcl.grid;

import org.zaval.data.*;
import org.zaval.data.event.*;
import org.zaval.lw.grid.*;

/**
 *supports sorting
 *repaints on model event
 *
 * @author  mingfang
 */
public class Grid2 extends LwGrid{
    /**
     *wrapper model that does the sorting
     */
    SortGridModel sortModel = new SortGridModel();
    /** Creates a new instance of FXGrid */
    public Grid2() {
        setModel(sortModel);
    }
    
    public Grid2(MatrixModel model){
        this();
        sortModel.setModel(model);
        add(LwGrid.TOP_CAPTION_EL, createGridCaption());
    }
    
    /**
     *sets the new model into the wrapper
     */
    public void setModel(MatrixModel model){
        sortModel.setModel(model);
    }
    
    /**
     *helper to create a sorting caption
     */
    public SortGridCaption createGridCaption(){
        SortGridCaption caption = new SortGridCaption(this, sortModel);
        return caption;
    }
    
    /**
     *repaint whole grid when resized
     */
    public void matrixResized(MatrixEvent e) {
        super.matrixResized(e);
        repaint();
    }
    
    /**
     *repaint row that changed
     */
    public void cellModified(MatrixEvent e) {
        super.cellModified(e);
        int x = getColX(e.getModifiedCell().x);
        int y = getRowY(e.getModifiedCell().y);
        //int width = getColWidth(e.getModifiedCell().x);
        int width = getSize().width;
        int height = getRowHeight(e.getModifiedCell().y);
        repaint (x, y, width, height);
    }
    
}
