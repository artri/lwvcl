/*
 * GridCaption.java
 *
 * Created on October 1, 2002, 4:41 PM
 */

package lwvcl.grid;

import org.zaval.lw.event.*;
import org.zaval.lw.grid.*;

/**
 *sorts when clicked on header
 *
 * @author  mingfang
 */
public class SortGridCaption extends LwGridCaption implements LwMouseListener{
    LwGridMetrics metrics;
    SortGridModel model;
    /** Creates a new instance of GridCaption */
    public SortGridCaption(LwGridMetrics m, SortGridModel model) {
        super(m);
        this.metrics = m;
        this.model = model;
    }
    
    /** <font face="Arial" size="2">
     * Invoked when the mouse button has been clicked on a light weight component.
     * @param <code>e</code> the specified mouse event.
     * </font>
     *
     */
    int sortCol = -1;
    boolean ascending = true;
    
    public void mouseClicked(LwMouseEvent e) {
        int col = getColIndex(e.getX());
        //ascending when first clicked
        if(col != sortCol){
            ascending = true;
            sortCol = col;
        }
        model.sortByColumn(sortCol, ascending);
        //change direction next time
        ascending = !ascending;
    }
    
    /**
     *findout what column was clicked
     */
    protected int getColIndex(int x){
        int colIndex = -1;
        int num = metrics.getGridCols();
        for(int i=0; i<num; i++){
            int x1 = metrics.getColX(i);
            int x2 = metrics.getColX(i+1);
            if(x >= x1 && x <=x2){
                colIndex = i;
                break;
            }
        }
        return colIndex;
    }
    
    /** <font face="Arial" size="2">
     * Invoked when the mouse enters a light weight component.
     * @param <code>e</code> the specified mouse event.
     * </font>
     *
     */
    public void mouseEntered(LwMouseEvent e) {
    }
    
    /** <font face="Arial" size="2">
     * Invoked when the mouse exits a light weight component.
     * @param <code>e</code> the specified mouse event.
     * </font>
     *
     */
    public void mouseExited(LwMouseEvent e) {
    }
    
    /** <font face="Arial" size="2">
     * Invoked when the mouse button has been pressed on a light weight component.
     * @param <code>e</code> the specified mouse event.
     * </font>
     *
     */
    public void mousePressed(LwMouseEvent e) {
    }
    
    /** <font face="Arial" size="2">
     * Invoked when the mouse button has been released on a light weight component.
     * @param <code>e</code> the specified mouse event.
     * </font>
     *
     */
    public void mouseReleased(LwMouseEvent e) {
    }
    
}
